import random

for ts in range(15, 20):
    n = random.randint(1, 1)
    q = random.randint(1, 100)
    l = []
    for i in range(n):
        l.append(random.randint(1, 1))
    k = []
    for i in range(q):
        k.append(random.randint(1, 1000000000))
    f = open(("input" + str(ts) + ".txt"),"w")
    f.write(str(n) + " " + str(q) + "\n")
    for j in l:
        f.write(str(j) + " ")
    f.write("\n")
    for j in k:
        f.write(str(j) + " ")
    f.write("\n")
    f.close
